declare module '@paypal/checkout-server-sdk';
